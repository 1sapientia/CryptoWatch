data format:
list of orderbook updates represented as a list of three float elements [timestamp, price, amount]
each update updates its price point amount in the orderbook.

orderbook reconstruction:

if the amount is negative: 
    abs(price) asks pricepoint is set to abs(amount) 
if the amount is positive: 
    abs(price) bids pricepoint is set to abs(amount) 
if the amount is 0: 
    if the price is negative:
        abs(price) pricepoint is removed from the asks
    else:
        abs(price) pricepoint is removed from the bids


the files contain updates for the day of 4. 11. 2019. The snapshot is contained in the first 2 minutes of updates. Use them to construct the orderbook and start the arbitrage at 00:02+

There are 3 pairs on 3 exchanges which allows you to test multihop functionality.

enjoy!

 
 



